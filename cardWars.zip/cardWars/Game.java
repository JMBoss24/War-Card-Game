import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.util.*;
import java.awt.event.*;

public class Game extends Canvas{
    private static ArrayList<ArrayList<String>> decks;
    private static ArrayList<String> computer;
    private static ArrayList<String> player1;
    private static ArrayList<String> player2;
    private static ArrayList<String> player3;
    private static ArrayList<String> player4;
    private static String p1Card;
	private static String p2Card;
	private static String p3Card;
    private static String p4Card;
    private static  int [] newPoints = new int[4];
    public static void main(String[] args){
        //Part one explaining rules of the game and getting number of players that will be playign
    Scanner in = new Scanner(System.in);  
    System.out.println("Welcome to Card War \nRules of Play are as follows:\nEach player plays a randomnly selected card from their Deck.\nThe player who plays a card with highest rank wins the game.\nIn Case of a tie of ranks a Standoff will occur.\nIn the Standoff a randomn number will be generated players in Standoff would have to guess what that number is\nPlayer with the closest guess to the number gets the points\nThis game relies on luck. So good luck!!\nEnter number of Players");
    int numPlayers = in.nextInt();
    int [] num = new int[1];//usign an int[] for most operations because in some instances we can't change primitive variables in  a  mouseListener, many of succ arrays exist
    num[0] = numPlayers;
    
    //creating new canvas and new frame
    Canvas canvas = new Game();
    canvas.setBackground(Color.BLUE);
    JFrame frame = new JFrame("Card War");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

   
    frame.add(canvas);
    frame.setSize(800, 450);
    frame.setVisible(true);
    canvas.createBufferStrategy(2);
    int[] arr = new int[11];
    int [] players = new int [4];
    for(int i = 0; i<players.length; i++){
    players[i] = i+1;    
    }
    //call in playerDecks method to be able to get each shuffled deck for player
    playerDecks p = new playerDecks();
    Gameplay play = new Gameplay();// call in Gameplay to intialise how the game is played
    BufferStrategy strategy = canvas.getBufferStrategy();
    //according to number of players playing this retrieves shuffled and dstributed decks from the playerDecks class
    if (num[0] == players[0]){ //against computer gets 2 decks one for computer one for user
        decks = p.twoPlayer();
        computer = decks.get(0);
        player1 = decks.get(1);
    }
    if (num[0] == players[1]){ //against another user retrieves to arraylists with decks and so on up until four
        decks = p.twoPlayer();
        player1 = decks.get(0);
        player2 = decks.get(1);
    }
    if (num[0] == players[2]){ 
        decks = p.threePlayer();
        player1 = decks.get(0);
        player2 = decks.get(1);
        player3 = decks.get(2);
    }
    if (num[0] == players[3]){
        decks = p.fourPlayer();
        player1 = decks.get(0);
        player2 = decks.get(1);
        player3 = decks.get(2);
        player4 = decks.get(3);
    }
    int [] ind = new int[9]; //an array with 9 wasnt really necessary but for sake of avoiding numbers not resetted it was created, this is basically for the ind of the card in the deck
    int [] points = new int[4];
   
    int [] playersPlayed = new int[4]; //this is to regulate the number of players that have played their cards  before we can move into calling the game each index represents
    //..a number of players game  being for 1 player and so on  
    //NB: a lot of this code on the mouse listener is repetitive so we will explain for two players and the others it's the same but just with more players
    canvas.addMouseListener(new MouseAdapter(){
        public void mouseClicked(MouseEvent e){ // our mouse listener, on reacts when coordinates where cards lie are clicked
            int x = e.getX();
            int y = e.getY();
            Graphics g = strategy.getDrawGraphics();
            if(num[0] == players[0]){ //game against computer
                if(x > arr[2] && x < arr[2]+arr[0] && y> arr[4] && y<arr[4]+arr[1]){ 
                    
                    System.out.println("Player PLayed Card"); //alerts that a card has been played upon click
                    p2Card = player1.get(ind[0]); //get ind[0] of the player's deck array and incremenrs
                    String imagePath2 = p2Card+".png"; //creation of an image path
                    Image img2 = new ImageIcon(imagePath2).getImage(); //
                    g.drawImage(img2, arr[2] -arr[0],arr[4], arr[0], arr[1], null); //drawing the image using g graphics in the appropriate coordinates
                  
                    System.out.println("Computer Played Card");
                    p1Card = computer.get(ind[0]);
                    String imagePath = p1Card+".png";
                    Image img = new ImageIcon(imagePath).getImage();
                    g.drawImage(img, arr[2] +arr[0],arr[3], arr[0], arr[1], null); 
                    g.clearRect(arr[2]+10,arr[3]+arr[1], arr[0]+20, 20);
                    g.clearRect(arr[2]+10,arr[4]+arr[1], arr[0]+20, 20);
                   
                        newPoints = play.playWithPC(p1Card, p2Card, points);
                        gra.setColor(Color.WHITE);
                        gra.drawString("Computer Points = "+newPoints[0],arr[2]+10, arr[3]+arr[1]+10); //writes player points on the GUI
                        gra.drawString("Player Points = "+newPoints[1],arr[2]+10, arr[4]+arr[1]+10);
                        ind[0] = ind[0]+1;
                        if (ind[0] == player1.size()-1 && ind[0]== player2.size()-1){
                            System.out.println("Game Over");
                            if(newPoints[0]>newPoints[1]){
                                System.out.println("Game Over. Computer wins!");
                            }
                            else{
                                System.out.println("Game Over. Player wins!");
                            }
                            frame.setVisible(false); //makes the frame invisible
                            frame.dispose();
                            
                        }
                }
            }
            if (num[0] == players[1]){ //for two players
                if(x > arr[2] && x < arr[2]+arr[0] && y> arr[3] && y<(arr[3]+arr[1])){
                    //Graphics g = Canvas.getGraphics();
                    System.out.println("Player 1 played card");
                    p1Card = player1.get(ind[0]);
                    String imagePath = p1Card+".png";
                    Image img = new ImageIcon(imagePath).getImage();
                    g.drawImage(img, arr[2] +arr[0],arr[3], arr[0], arr[1], null);
                    ind[0] = ind[0]+1;
                    playersPlayed[0] = playersPlayed[0] +1;
                } 
                if(x > arr[2] && x < arr[2]+arr[0] && y> arr[4] && y<arr[4]+arr[1]){
                    System.out.println("Player 2 played card");
                    p2Card = player2.get(ind[1]);
                    String imagePath = p2Card+".png";
                    Image img = new ImageIcon(imagePath).getImage();
                    g.drawImage(img, arr[2] -arr[0],arr[4], arr[0], arr[1], null);
                    ind[1] = ind[1]+1;
                    playersPlayed[0] = playersPlayed[0] +1;
                }
                if (playersPlayed[0] == 2){
                    g.clearRect(arr[2]+10,arr[3]+arr[1], arr[0]+20, 20);
                    g.clearRect(arr[2]+10,arr[4]+arr[1], arr[0]+20, 20);
                    newPoints = play.playGame2(p1Card, p2Card, points);
                    g.setColor(Color.WHITE);
                    g.drawString("Player 1 Points = "+newPoints[0],arr[2]+10, arr[3]+arr[1]+10);
                    g.drawString("Player 2 Points = "+newPoints[1],arr[2]+10, arr[4]+arr[1]+10);
                    if (ind[0] == player1.size()-1 && ind[1]== player2.size()-1){ //when players have played their last cards it compares which 
                        System.out.println("Game Over");
                        if(newPoints[0]>newPoints[1]){
                            System.out.println("Player One wins");
                        }
                        else{
                            System.out.println("Player Two wins");
                        }
                        frame.setVisible(false); //closes frame once game is done
                        frame.dispose();
                        
                    }

                    playersPlayed[0] = 0;
                    ;
                }
                
                    
                
            }
            if (num[0] == players[2]){ //for three players
                if(x > arr[2] && x < arr[2]+arr[0] && y> arr[3] && y<(arr[3]+arr[1])){
                    System.out.println("Player 1 played card");
                    p1Card = player1.get(ind[2]);
                    String imagePath = p1Card+".png";
                    Image img = new ImageIcon(imagePath).getImage();
                    g.drawImage(img, arr[2] +arr[0],arr[3], arr[0], arr[1], null);
                    ind[2] = ind[2]+1;
                    playersPlayed[1] = playersPlayed[1] +1;
                }
                if(x > arr[2] && x < arr[2]+arr[0] && y> arr[4] && y<arr[4]+arr[1]){
                    System.out.println("Player 2 played card");
                    p2Card = player2.get(ind[3]);
                    String imagePath =p2Card+".png";
                    Image img = new ImageIcon(imagePath).getImage();
                    g.drawImage(img, arr[2] -arr[0],arr[4], arr[0], arr[1], null);
                    ind[3] = ind[3]+1;
                    playersPlayed[1] = playersPlayed[1] +1;
                }
                if(x > arr[5] && x < arr[5]+arr[0] && y> arr[6] && y<arr[6]+arr[1]){ 
                    System.out.println("Player 3 played card");
                    p3Card = player3.get(ind[4]);
                    String imagePath = p3Card+".png";
                    Image img = new ImageIcon(imagePath).getImage();
                    g.drawImage(img, arr[5] + arr[0],arr[6], arr[0], arr[1], null);
                    ind[4] = ind[4]+1;
                    playersPlayed[1] = playersPlayed[1] +1;
            } 
            if (playersPlayed[1] == 3){
                g.clearRect(arr[2]+10,arr[3]+arr[1], arr[0]+20, 20);
                g.clearRect(arr[2]+10,arr[4]+arr[1], arr[0]+20, 20);
                g.clearRect(arr[5]+10,arr[6]+arr[1], arr[0]+20, 20);
                newPoints = play.playGame3(p1Card, p2Card, p3Card, points);
                g.setColor(Color.WHITE);
                g.drawString("Player 1 Points = "+newPoints[0],arr[2]+10, arr[3]+arr[1]+10);
                g.drawString("Player 2 Points = "+newPoints[1],arr[2]+10, arr[4]+arr[1]+10);
                g.drawString("Player 3 Points = "+newPoints[2], arr[5]+10, arr[6]+arr[1]+10);
               
                if (ind[2] == player1.size()-1 && ind[3]== player2.size()-1 && ind[4] == player3.size()-1){
                    int highest = newPoints[0];
                    int compare; 
                    if(newPoints[1]>newPoints[2]){
                        compare = newPoints[1];
                    }
                    else{
                        compare = newPoints[2];  
                    }
                    if(highest<compare){
                        highest = compare;
                    }
                    if(highest == newPoints[0]){
                        g.drawString("Game Over. Player One Wins", arr[9], arr[10]);
                    }
                    else if(highest == newPoints[1]){
                        g.drawString("Game Over. Player Two Wins", arr[9], arr[10]);
                    }
                    else if(highest == newPoints[2]){
                        g.drawString("Game Over. Player Three Wins", arr[9], arr[10]);
                    }
                    frame.setVisible(false); //you can't see me!
                    frame.dispose();
                }
                playersPlayed[1] = 0;
            }
           
        }
            if (num[0] == players[3]){ //for four players
                if(x > arr[2] && x < arr[2]+arr[0] && y> arr[3] && y<(arr[3]+arr[1])){ 
                    System.out.println("Player 1 played card");
                    p1Card = player1.get(ind[5]);
                    String imagePath = p1Card+".png";
                    Image img = new ImageIcon(imagePath).getImage();
                    g.drawImage(img, arr[2] +arr[0],arr[3], arr[0], arr[1], null);
                    ind[5] = ind[5]+1;
                    playersPlayed[2] = playersPlayed[2] +1;
                    
                }
                if(x > arr[2] && x < arr[2]+arr[0] && y> arr[4] && y<arr[4]+arr[1]){
                    System.out.println("Player 2 played card");
                    p2Card = player2.get(ind[6]);
                    String imagePath =p2Card+".png";
                    Image img = new ImageIcon(imagePath).getImage();
                    g.drawImage(img, arr[2] -arr[0],arr[4], arr[0], arr[1], null);
                    ind[6] = ind[6]+1;
                    playersPlayed[2] = playersPlayed[2] +1;
                }
                if(x > arr[5] && x < arr[5]+arr[0] && y> arr[6] && y<arr[6]+arr[1]){
                    System.out.println("Player 3 played card");
                    p3Card = player3.get(ind[7]);
                    String imagePath = p3Card+".png";
                    Image img = new ImageIcon(imagePath).getImage();
                    g.drawImage(img, arr[5] + arr[0],arr[6], arr[0], arr[1], null);
                    ind[7] = ind[7]+1;
                    playersPlayed[2] = playersPlayed[2] +1;
                }
                if(x > arr[7] && x < arr[7]+arr[0] && y> arr[8] && y<arr[8]+arr[1]){
                    System.out.println("Player 4 played card");
                    p4Card = player4.get(ind[8]);
                    String imagePath = p4Card+".png";
                    Image img = new ImageIcon(imagePath).getImage();
                    g.drawImage(img, arr[7] - arr[0],arr[8], arr[0], arr[1], null); 
                    ind[8] = ind[8]+1; 
                    playersPlayed[2] = playersPlayed[2] +1;
            } 
            if (playersPlayed[2] == 4){
                g.clearRect(arr[2]+10,arr[3]+arr[1], arr[0]+20, 20);
                g.clearRect(arr[2]+10,arr[4]+arr[1], arr[0]+20, 20);
                g.clearRect(arr[5]+10,arr[6]+arr[1], arr[0]+20, 20);
                g.clearRect(arr[7]+10,arr[8]+arr[1], arr[0]+20, 20);
                
                newPoints = play.playGame4(p1Card, p2Card, p3Card, p4Card, points);
                g.setColor(Color.WHITE);
                g.drawString("Player 1 Points = "+newPoints[0],arr[2]+10, arr[3]+arr[1]+10);
                g.drawString("Player 2 Points = "+newPoints[1],arr[2]+10, arr[4]+arr[1]+10);
                g.drawString("Player 3 Points = "+newPoints[2], arr[5]+10, arr[6]+arr[1]+10);
                g.drawString("Player 4 Points = "+newPoints[3], arr[7]+10, arr[8]+arr[1]+10);
                if (ind[5] == player1.size()-1 && ind[6]== player2.size()-1 && ind[7] == player3.size()-1 && ind[8] == player4.size()){
                    int [] finalPoints = newPoints;
                    Arrays.sort(finalPoints);
                   
                    if(newPoints[0] ==  finalPoints[3]){
                        System.out.println("Game Over. Player One Wins!");
                    }
                    else if(newPoints[1] ==  finalPoints[3]){
                        System.out.println("Game Over. Player Two Wins!");
                    }
                    else if(newPoints[2] ==  finalPoints[3]){
                        System.out.println("Game Over. Player Three Wins!");
                    }
                    else if(newPoints[3] ==  finalPoints[3]){
                        System.out.println("Game Over. Player Four Wins!");
                    }
                    frame.setVisible(false); //you can't see me!
                    frame.dispose();
                }
                playersPlayed[2]=0;
            }
        }
    }
            
    });
    

    while(true){ //this loop is to keep background of the cards that user will interface with running so while true, the back will always show
        Graphics graphics = strategy.getDrawGraphics();
        graphics.setColor(Color.WHITE);
        arr[0] = 25*((canvas.getWidth()/canvas.getHeight())*5); // cW
        arr[1] = 35*((canvas.getWidth()/canvas.getHeight())*5); // cH
        arr[2] = (canvas.getWidth()/2)-(arr[0]/2); // p12x
        arr[3] = 30*(canvas.getHeight()/100)-arr[1]; // p1y
        arr[4] = 70*(canvas.getHeight()/100); // p2y
        arr[5] =(canvas.getWidth()/4)-(arr[0]/2); //p3x
        arr[6] = (canvas.getHeight()/2)-(arr[1]/2); //py3
        arr[7] = (canvas.getWidth()*3/4)-(arr[0]/2); //p4x
        arr[8] = (canvas.getHeight()/2)-(arr[1]/2); //p4y
        arr[9] = (canvas.getWidth()/2)-20;
        arr[10] = (canvas.getHeight()/2);

    if (num[0] == players[0]){ //draws board for player vs computer
        Image img = Toolkit.getDefaultToolkit().getImage("back.png");
        graphics.drawString("*** COMPUTER ***", arr[2]+10,arr[3]-10);
        graphics.drawImage(img, arr[2],arr[3], arr[0], arr[1], null);
        graphics.drawString("*** PLAYER ***",arr[2]+10,arr[4]-10);
        graphics.drawImage(img, arr[2],arr[4], arr[0], arr[1], null);
    

    }
    if (num[0] == players[1]){ //draws playing field for  2 players
        Image img = Toolkit.getDefaultToolkit().getImage("back.png");
        graphics.drawString("*** PLAYER 1 ***", arr[2]+10,arr[3]-10);
        graphics.drawImage(img, arr[2],arr[3], arr[0], arr[1], null);
        graphics.drawString("*** PLAYER 2 ***",arr[2]+10,arr[4]-10);
        graphics.drawImage(img, arr[2],arr[4], arr[0], arr[1], null);
    

    }
    if (num[0] == players[2]){//for 3 players
        Image img = Toolkit.getDefaultToolkit().getImage("back.png");
        graphics.drawString("*** PLAYER 1 ***", arr[2]+10,arr[3]-10);
        graphics.drawImage(img, arr[2],arr[3], arr[0], arr[1], null);
        graphics.drawString("*** PLAYER 2 ***",arr[2]+10,arr[4]-10);
        graphics.drawImage(img, arr[2],arr[4], arr[0], arr[1], null);
        graphics.drawString("*** PLAYER 3 ***", arr[5]+10, arr[6]-10);
        graphics.drawImage(img, arr[5],arr[6], arr[0], arr[1], null);
    }
    if (num[0] == players[3]){//for four players
        Image img = Toolkit.getDefaultToolkit().getImage("back.png");
        graphics.setColor(Color.WHITE);
        graphics.drawString("*** PLAYER 1 ***", arr[2]+10,arr[3]-10);
        graphics.drawImage(img, arr[2],arr[3], arr[0], arr[1], null);
        graphics.drawString("*** PLAYER 2 ***",arr[2]+10,arr[4]-10);
        graphics.drawImage(img, arr[2],arr[4], arr[0], arr[1], null);
        graphics.drawString("*** PLAYER 3 ***", arr[5]+10, arr[6]-10);
        graphics.drawImage(img, arr[5],arr[6], arr[0], arr[1], null);
        graphics.drawString("*** PLAYER 4 ***", arr[7]+10,arr[8]-10);
        graphics.drawImage(img, arr[7], arr[8], arr[0], arr[1], null);
    }      
    strategy.show();
    graphics.dispose();
}
}
}