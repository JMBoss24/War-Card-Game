import java.util.*;
import java.awt.*;

public class Battle{
    private static int PCguess;
    private static int p1;
    private static int p2;
    private static int p3;
    private static int p4;
    // this class resolves our standoff in each difference instance of four, 3 or 2 ties the players are asked to guess a randomly generated number form 0 to a 100 and the guess that's the closest
    //to the number gets two points 

	public void Battle()
	{
	}
	public int  [] Players1 (int [] points){
		Random Rand= new Random();
		int num=0;
		Scanner in = new Scanner(System.in);
		
		while (true){
			num=Rand.nextInt(100);
			this.PCguess =Rand.nextInt(100);
			System.out.println("computer guessed Guessed "+PCguess);
			//////
			System.out.println("Player  Guess a number between 0 and 100");
			this.p1 =in.nextInt();
			 if (this.PCguess!=this.p1){
				 break;
				}
			
		}
        System.out.println("Number to guess was "+ num);
		if (Math.abs(num-this.PCguess)<Math.abs(num-this.p1)){
			System.out.println("computer wins the Standoff +2 points Continue game");
			points[0] = points[0]+2;
		}
		else{
			System.out.println("player  wins the Standoff +2 points Continue game");
			points[1] = points[1]+2;
        }
        return points;
		}
	public int[] Players2 (int [] points, int a, int b){ // in the case of a two way tie 
			Random Rand= new Random();
			int num;
			Scanner in = new Scanner(System.in);
			System.out.println("Guess a number between 0 and 100");
			
			while (true){
				num=Rand.nextInt(100);
				System.out.println("player "+ a +" Guess a number between 0 and 100");
				this.p1 =in.nextInt();
				System.out.println("player " + b + " Guess a number between 0 and 100");
				this.p2=in.nextInt();
				 if ((this.p1!=this.p2)){
					 break;
					}
				
			}
			System.out.println("The number to guess was "+ num);
			if (Math.abs(num-this.p1)<Math.abs(num-this.p2)){
				System.out.println("player "+ a +" vwins the Standoff +2 points Continue game");
				points[a-1] = points[a-1]+2;
			}
			else{
				System.out.println("player "+b+" wins the Standoff +2 points Continue game");
				points[b-1] = points[b-1]+2;
			}
		return points;
		
	}
	

	public int [] Players3 (int [] points, int a, int b, int c){ // in the case of a three way tie
			Random Rand= new Random();
			int num;
			Scanner in = new Scanner(System.in);
			
			while (true){
				num=Rand.nextInt(100);
				System.out.println("player "+a+ " Guess a number between 0 and 100");
				this.p1=in.nextInt();
				
				System.out.println("player " +b+" Guess a number between 0 and 100");
				this.p2=in.nextInt();
				
				System.out.println("player " +c+" Guess a number between 0 and 100");
				this.p3=in.nextInt();
				 if ((this.p1!=this.p2)&&this.p1!=this.p3&&this.p2!=this.p3){
					 break;
					}
				
			}
			System.out.println("The number to guess was "+ num);
			if ((Math.abs(num-this.p1)<Math.abs(num-this.p2))&&Math.abs(num-this.p1)<Math.abs(num-this.p3)){
				System.out.println("player "+a+ " wins the Standoff +2 points Continue game");
				points[a-1] = points[a-1]+2;
			}
			else if (Math.abs(num-this.p2)<Math.abs(num-this.p1)&&Math.abs(num-this.p2)<Math.abs(num-this.p3)){
				System.out.println("player" +b+" wins the Standoff +2 points Continue game");
				points[b-1] = points[b-1]+2;
			}
			else{
				System.out.println("player " +c+" wins the Standoff +2 points Continue game");
				points[c-1] = points[c-1]+2;
			}
			return points;
		}
	
	public int [] Players4 (int [] points, int a, int b, int c, int d){ // in the case of a four way tie
		Random Rand= new Random();
		int num;
		Scanner in = new Scanner(System.in);
		
		while (true){
			num=Rand.nextInt(100);
			System.out.println("player "+a+ " Guess a number between 0 and 100");
			this.p1=in.nextInt();
			
			System.out.println("player " +b+" Guess a number between 0 and 100");
			this.p2=in.nextInt();
			
			System.out.println("player " +c+" Guess a number between 0 and 100");
			this.p3=in.nextInt();
			System.out.println("player " +d+" Guess a number between 0 and 100");
			this.p4=in.nextInt();
			 if (this.p1!=this.p2 && this.p1!=this.p3 && this.p2!=this.p3 && this.p1!=this.p4 && this.p3 != this.p4 && this.p2 != this.p4){
				 break;
				}
			
		}
		System.out.println("The number to guess was "+ num);
		if (Math.abs(num-this.p1)<Math.abs(num-this.p2)&&Math.abs(num-this.p1)<Math.abs(num-this.p3)&&Math.abs(num-this.p1)<Math.abs(num-this.p4)){
			System.out.println("player "+a+ " wins the Standoff+2 points Continue game");
			points[a-1] = points[a-1]+2;
		}
		else if (Math.abs(num-this.p2)<Math.abs(num-this.p1)&&Math.abs(num-this.p2)<Math.abs(num-this.p3)&&Math.abs(num-this.p2)<Math.abs(num-this.p4)){
			System.out.println("player" +b+" wins the Standoff +2 points Continue game");
			points[b-1] = points[b-1]+2;
		}
		else if (Math.abs(num-this.p3)<Math.abs(num-this.p1)&&Math.abs(num-this.p3)<Math.abs(num-this.p3)&&Math.abs(num-this.p3)<Math.abs(num-this.p4)){
			System.out.println("playerd "+c+" wins the Standoff +2 points Continue game");
			points[c-1] = points[c-1]+2;
		}
		else{
			System.out.println("player " +d+" wins the Standoff +2 points Continue game");
			points[d-1] = points[d-1]+2;
		}
		return points;
	}		
		
}		