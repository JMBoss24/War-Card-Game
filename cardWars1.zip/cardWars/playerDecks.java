import java.util.*;

public class playerDecks{
    private ArrayList<ArrayList<String>> decks;
	public ArrayList<ArrayList<String>> twoPlayer(){
        distribute play=new distribute();
        this.decks=play.dist(2);// //divides deck between two players
        return this.decks;
                
    }  
    public ArrayList<ArrayList<String>> threePlayer(){
        distribute play=new distribute();
        this.decks=play.dist(3);// divides decks amongst 3 players
        return this.decks;
                
    }   
    public ArrayList<ArrayList<String>> fourPlayer(){
        distribute play=new distribute();
        this.decks=play.dist(4);//divides deck amongst four players
        return this.decks;
                
	}    
}