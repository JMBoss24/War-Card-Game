import java.util.*;
import java.lang.Math; 
public class distribute {
	private ArrayList<String> player1;
	private ArrayList<String> player2;
	private ArrayList<String> player3;
	private ArrayList<String> player4;
	private ArrayList<String> computer;
	private int[]  arr1;
	private String[] arr2;
	private double entropy;
	
  public distribute() {
	// intialising ///
	this.player1= new ArrayList<String>();// empty array///
	this.player2 =new ArrayList<String>();
	this.player3= new ArrayList<String>();
	this.player4= new ArrayList<String>();
	this.computer= new ArrayList<String>();
	this.entropy=0.0;
	////
	////creates deck of cards /// initialises arr1 and 2////
	 this.arr1=new int[52];
	 for (int i=0;i<this.arr1.length;i++){
		this.arr1[i]=i+1;
	 }
		
		///// this array changes according to the one ontop///
		
		String[] ranks = { "A", "2", "3", "4", "5", "6",
           "7", "8", "9", "X", "J", "Q", "K"};
		String[] suits = {"S", "C", "D", "H"};
		this.arr2= new String[52];
		int n=0; //for indexes;
		for  (int b=0;b<suits.length;b++){
			for  (int k=0;k<ranks.length;k++){
				this.arr2[n]=ranks[k]+suits[b];
				n++;
			}
		}
		//// generates ordered array
  }
  private void noForShanon(double  times){  //// will continue shuffling untill the  desired entropy is found///
		if (times==0.0){
			///means that they want an ordered cards therefore no shuflling will occur///
		     }
		while (!(this.entropy>times)){
			shuffle();
		}
	
	
    }
  private  void shuffle(){ // you will call this one when telling ////
  ///the program how many times to shuffle so there is no need to make it public//
	   Random rand = new Random();
	   int randI=0;
	   int randE=0;
	   String randE2="";// for all deck
	   for (int i=0;i< this.arr1.length;i++){
		  randI= rand.nextInt( this.arr1.length);
		  ////
		  randE= this.arr1[randI];
		  randE2=this.arr2[randI];
		  /////
		  this.arr1[randI]= this.arr1[i];
		  this.arr2[randI]=arr2[i];
		  //////
		  this.arr1[i]= randE;
		  this.arr2[i]= randE2;
		  
		  ///////////
	   }
	   shannon();
	}
	
	//// for shannon enthropy///
  private void  shannon (){/// there is no need for user to have acces to this//
		this.entropy=0.0;
		 int[] arry= new int [this.arr1.length];
		 /// for diff////
		 for (int i=0;i<this.arr1.length;i++){
		   int clc =this.arr1[i]-this.arr1[(i+1)%this.arr1.length];
		   if (clc<0){
			 clc+=this.arr1.length;
		   }
		   arry[clc]++;
		  }
		for (int k=0;k<arry.length;k++){
		  if (arry[k]>0){
			double freq=(double) arry[k]/this.arr1.length;
			this.entropy-=freq*Math.log(freq)/Math.log(2.0);
			this.entropy = Math.round(this.entropy * 100D) / 100D;

		   }
		}
	
 
    }
  public ArrayList<ArrayList<String>> dist(int noPlayers ){
		 noForShanon(5.0);
	
		 if (noPlayers==1){ 
			for (int i=0;i<52;i++){
				this.computer.add(this.arr2[i]);
				this.player1.add(this.arr2[i+1]);
				i++;
			}
			/*System.out.println("computer: "+Arrays.toString(this.computer.toArray()));
			System.out.println("player1: "+Arrays.toString(this.player1.toArray()));*/
			
			ArrayList<ArrayList<String>> distributed= new ArrayList<ArrayList<String>>();
			distributed.add(this.computer);
			distributed.add(this.player1);
			return 	distributed;
			
		 }
		 else if (noPlayers==2){
			
			for (int i=0;i<52;i++){
				this.player1.add(this.arr2[i]);
				this.player2.add(this.arr2[i+1]);
				i++;
			}
			/*System.out.println("player1: "+Arrays.toString(this.player1.toArray()));
			System.out.println("player2: "+Arrays.toString(this.player2.toArray())); */
		
			ArrayList<ArrayList<String>> distributed= new ArrayList<ArrayList<String>>();
			distributed.add(this.player1);
			distributed.add(this.player2);
			return 	distributed;
		 }
		 
		 else if (noPlayers==3){
			int b=0;
			for (int i=0;i<51;i++){
				if (b>=17){
					continue;
				}
				this.player1.add(this.arr2[i]);
				this.player2.add(this.arr2[i+1]);
				this.player3.add(this.arr2[i+2]);
				b++;
				i+=2;
				

				
			}
			/*System.out.println("player1: "+Arrays.toString(this.player1.toArray()));
			System.out.println("player2: "+Arrays.toString(this.player2.toArray())); 
			System.out.println("player3: "+Arrays.toString(this.player3.toArray())); */
			
			ArrayList<ArrayList<String>> distributed= new ArrayList<ArrayList<String>>();
			distributed.add(this.player1);
			distributed.add(this.player2);
			distributed.add(this.player3);
			return 	distributed;
		 
			 
		 }
		else  if (noPlayers==4){
			for (int i=0;i<52;i++){
				
				this.player1.add(this.arr2[i]);
				this.player2.add(this.arr2[i+1]);
				this.player3.add(this.arr2[i+2]);
				this.player4.add(this.arr2[i+3]);
				i+=3;
				
			}
			/*System.out.println("original: "+Arrays.toString(this.computer.toArray()));
			System.out.println("player1: "+Arrays.toString(this.player1.toArray()));
			System.out.println("player2: "+Arrays.toString(this.player2.toArray())); 
			System.out.println("player3: "+Arrays.toString(this.player3.toArray())); 
			System.out.println("player4: "+Arrays.toString(this.player4.toArray())); */
			
			ArrayList<ArrayList<String>> distributed= new ArrayList<ArrayList<String>>();
			distributed.add(this.player1);
			distributed.add(this.player2);
			distributed.add(this.player3);
			distributed.add(this.player4);
			return 	distributed;
		 
		}
		else{
		 System.out.println("you can can only have  between 1 and 4 players");
		 ArrayList<ArrayList<String>> distributed= new ArrayList<ArrayList<String>>();
		 return distributed;
		}
    }
}