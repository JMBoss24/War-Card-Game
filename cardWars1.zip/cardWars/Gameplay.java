import java.util.*;
import javax.swing.*;
import java.awt.*;
////////
class Gameplay{
	private String p1Card;
	private String p2Card;
	private String p3Card;
	private String p4Card;
	private Battle standOff = new Battle();
	////////
	//turn character into string
	
	public int getNoRank(char R){
		if (R == 'A'){
			return 1; 
		}
		if (R == 'X'){
			return 10; 
		}
		
		else if (R == 'J'){
			return 11; 
		}
		else if (R == 'Q'){
			return 12; 
		} 
		else if (R == 'K'){
			return 13; 
		}
		else {
			return Character.getNumericValue(R); 
		}
	}
	public int [] playWithPC(String p1Card, String p2Card, int [] points){// One Player against Computer
		char c1 = p1Card.charAt(0);
		char c2 = p2Card.charAt(0);
		int c1a = getNoRank(c1);
		int c2a = getNoRank(c2);

		if (c1a > c2a){
			System.out.println("Computer wins this round. Point awarded to Computer");
			points[0] = points[0]+1 ;
		}
		if (c2a > c1a){
			System.out.println("Player wins this round. Point awarded to Player");
			points[1] = points[1]+1 ;
		}
		if (c2a == c1a){
			System.out.println("Looks like we have a Standoff");
			points = standOff.Players1(points);
		}
return points;
	
}   
	public int [] playGame2(String p1Card, String p2Card, int [] points){// two player game play
				char c1 = p1Card.charAt(0);
				char c2 = p2Card.charAt(0);
			 	int c1a = getNoRank(c1);
				int c2a = getNoRank(c2);
				
		
				if (c1a > c2a){
					System.out.println("Player 1 wins this round. Point awarded to player One");
					points[0] = points[0]+1 ;
				}
				if (c2a > c1a){
					System.out.println("Player 2 wins this round. Point awarded to Player two");
					points[1] = points[1]+1 ;
				}
				if (c2a == c1a){
					System.out.println("Looks like we have a Standoff");
					points = standOff.Players2(points, 1, 2);
				}
		return points;
			
	}   
	public int [] playGame3(String p1Card, String p2Card, String p3Card, int [] points){ //game play for three players 
		//the following checks the card ranks and then turns them into integers to be compared		
			char c1 = p1Card.charAt(0);
				char c2 = p2Card.charAt(0);
				char c3 = p3Card.charAt(0);
			 	int c1a = getNoRank(c1);
				int c2a = getNoRank(c2);
				int c3a = getNoRank(c3);

				int [] cards = new int[3];
				cards[0] = c1a;
				cards[1] = c2a;
				cards[2] = c3a; 
				Arrays.sort(cards);
				System.out.println(Arrays.toString(cards));
				
				if(c1a == c2a && c2a == c3a){
					System.out.println("Looks like we have a Three way Standoff");
					points = standOff.Players3(points, 1,2,3);
				}
				else if(c1a == c2a){
					if(c3a>c1a){
						System.out.println("Player 3 wins this round. Point awarded to Player Three");
						points[2] = points[2]+1 ;
					}
					else{
						System.out.println("Looks like we have a standoff between player One and Two");
						points = standOff.Players2(points, 1, 2);
					}
					
				}
				else if(c1a == c3a){
					if(c2a>c1a){
						System.out.println("Player wins 2 this round. Point awarded to Player Two");
						points[1] = points[1]+1 ;
					}
					else{
						System.out.println("Looks like we have a standoff between player One and Three");
						points = standOff.Players2(points, 1, 3);

					}
				
				}
				else if(c2a == c3a){
					if(c1a>c2a){
						System.out.println("Player 1 wins this round. Point awarded to Player One");
						points[1] = points[1]+1 ;
					}
					else{
						System.out.println("Looks like we have a standoff between player Two and Three");
						points = standOff.Players2(points, 2, 3);

					}
				}
				else{
					if(cards[2]==c1a){
						System.out.println("Player 1 wins this round. Point awarded to Player One");
						points[0] = points[0]+1 ;
					}
					else if(cards[2]==c2a){
						System.out.println("Player 2 wins this round. Point awarded to Player two");
						points[1] = points[1]+1 ;
					}
					else if(cards[2]==c3a){
						System.out.println("Player 3 wins this round. Point awarded to Player three");
						points[2] = points[2]+1 ;
					}

				}	
	return points;
	}
	public int [] playGame4(String p1Card, String p2Card, String p3Card, String p4Card,  int [] points){ //Gameplay for when we have four players
		//the following checks the card ranks and then turns them into integers to be compared
		char c1 = p1Card.charAt(0);
		char c2 = p2Card.charAt(0);
		char c3 = p3Card.charAt(0);
		char c4 = p4Card.charAt(0);
		int c1a = getNoRank(c1);
		int c2a = getNoRank(c2);
		int c3a = getNoRank(c3);
		int c4a = getNoRank(c4);

		int [] cards = new int[4];
		cards[0] = c1a;
		cards[1] = c2a;
		cards[2] = c3a; 
		cards[3] = c4a; 
		Arrays.sort(cards); //sorts array to get highest value
		System.out.println(Arrays.toString(cards));
		
		//checks if all players played the same card if yes goes into a standoff battle
		if(c1a == c2a && c2a == c3a && c3a == c4a){
			System.out.println("Looks like we have a Four way Standoff");
			points = standOff.Players4(points, 1, 2, 3, 4);
		}
		//checks if three players play as card with the same rank and compares it to the one player who didnt if the similar classes have a higher ranking we go into a standoff battle
		//if not other player gets a point
		else if(c1a == c2a && c2a == c3a){
			if(c4a>c1a){
				System.out.println("Player 4 wins this round. Point awarded  to Player Four");
				points[4] = points[4]+1 ;
			}
			else{
				System.out.println("Looks like we have a standoff between player One, Two and Three");
				points = standOff.Players3(points, 1, 2, 3);
			}
			
		}
		else if(c2a == c3a && c3a== c4a){
			if(c1a>c2a){
				System.out.println("Player 1 wins this round. Point awarded  to Player One");
				points[0] = points[0]+1 ;
			}
			else{
				System.out.println("Looks like we have a standoff between player Two, Three and Four");
				points = standOff.Players3(points, 2, 3, 4);
			}
			
		}
		else if(c1a == c3a && c3a== c4a){
			if(c2a>c3a){
				System.out.println("Player 2 wins this round. Point awarded to Player Two");
				points[1] = points[1]+1 ;
			}
			else{
				System.out.println("Looks like we have a standoff between player One, Three and Four");
				points = standOff.Players3(points, 1, 3, 4);
			}
			
		}
		else if(c1a == c2a && c2a== c4a){
			if(c3a>c1a){
				System.out.println("Player 3 wins this round. Point awarded to Player Three");
				points[2] = points[2]+1 ;
			}
			else{
				System.out.println("Looks like we have a standoff between player One, Two and Four");
				points = standOff.Players3(points, 1, 2, 4);
			}
			
		}
		//checks if two players have a similar card and the cards are the highest ranked if yes goes into stand off or else checks which of the other two is the highest ranked
		else if(c1a == c2a){
			if(c1a == cards[3]){
				System.out.println("Looks like we have a standoff between player One and Two");
				points = standOff.Players2(points, 1, 2);
			}
			else if(cards[3]==c3a){
				System.out.println("Player 3 wins this round. Point awarded  to Player Three");
				points[2] = points[2]+1 ;
			}
			else if(cards[3]==c4a){
				System.out.println("Player 4 wins this round. Point awarded to Player Four");
				points[3] = points[3]+1 ;
			}
		}
		else if(c1a == c3a){
			if(c1a == cards[3]){
				System.out.println("Looks like we have a standoff between player One and Three");
				points = standOff.Players2(points, 1, 3);
			}
			else if(cards[3]==c2a){
				System.out.println("Player 2 wins this round. Point awarded  to Player Two");
				points[1] = points[1]+1 ;
			}
			else if(cards[3]==c4a){
				System.out.println("Player 4 wins this round. Point awarded to Player Four");
				points[3] = points[3]+1 ;
			}
		}
		else if(c1a == c4a){
			if(c1a == cards[3]){
				System.out.println("Looks like we have a standoff between player One and Four");
				points = standOff.Players2(points, 1, 4);
			}
			else if(cards[3]==c2a){
				System.out.println("Player 2 wins this round. Point awarded  to Player Two");
				points[1] = points[1]+1 ;
			}
			else if(cards[3]==c3a){
				System.out.println("Player 3 wins this round. Point awarded  to Player Three");
				points[2] = points[2]+1 ;
			}
		}
		else if(c2a == c3a){
			if(c2a == cards[3]){
				System.out.println("Looks like we have a standoff between player Two and Three");
				points = standOff.Players2(points, 2, 3);
			}
			else if(cards[3]==c1a){
				System.out.println("Player 1 wins this round. Point awarded to Player One");
				points[0] = points[0]+1 ;
			}
			else if(cards[3]==c4a){
				System.out.println("Player 4 wins this round. Point awarded to Player Four");
				points[3] = points[3]+1 ;
			}
		}
		else if(c2a == c4a){
			if(c2a == cards[3]){
				System.out.println("Looks like we have a standoff between player Two and Four");
				points = standOff.Players2(points, 2, 4);
			}
			else if(cards[3]==c1a){
				System.out.println("Player 1 wins this round. Point awarded to Player One");
				points[0] = points[0]+1 ;
			}
			else if(cards[3]==c3a){
				System.out.println("Player 3 wins this round. Point awarded  to Player Three");
				points[2] = points[2]+1 ;
			}
		}
		else if(c3a == c4a){
			if(c3a == cards[3]){
				System.out.println("Looks like we have a standoff between player Three and Four");
				points = standOff.Players2(points, 2, 3);
			}
			else if(cards[3]==c1a){
				System.out.println("Player 1 wins this round. Point awarded to Player One");
				points[0] = points[0]+1 ;
			}
			else if(cards[3]==c2a){
				System.out.println("Player 2 wins this round. Point awarded  to Player Two");
				points[1] = points[1]+1 ;
			}
			
		}
	
		else{
			if(cards[3]==c1a){
				System.out.println("Player 1 wins this round. Point awarded to Player One");
				points[0] = points[0]+1 ;
			}
			else if(cards[3]==c2a){
				System.out.println("Player 2 wins this round. Point awarded  to Player Two");
				points[1] = points[1]+1 ;
			}
			else if(cards[3]==c3a){
				System.out.println("Player 3 wins this round. Point awarded  to Player Three");
				points[2] = points[2]+1 ;
			}
			else if(cards[3]==c4a){
				System.out.println("Player 4 wins this round. Point awarded to Player Four");
				points[3] = points[3]+1 ;
			}

		}	
return points;
}	
}